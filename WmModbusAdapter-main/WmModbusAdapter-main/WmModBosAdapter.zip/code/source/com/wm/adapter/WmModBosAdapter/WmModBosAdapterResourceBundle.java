package com.wm.adapter.WmModBosAdapter;

import java.util.ListResourceBundle;
import com.wm.adk.ADKGLOBAL;

public class WmModBosAdapterResourceBundle extends ListResourceBundle implements WmModBusAdapterConstants {

	static final String IS_PKG_NAME = "/WmModBosAdapter/";
	
	 static final Object[][] _contents = {
			   // adapter type display name.
			   {ADAPTER_NAME + ADKGLOBAL.RESOURCEBUNDLEKEY_DISPLAYNAME, "WmModBosAdapter"}
			   // adapter type descriptions.
			   ,{ADAPTER_NAME + ADKGLOBAL.RESOURCEBUNDLEKEY_DESCRIPTION,
			    "Adapter for Client connection to ModBus Server "}
			   // adapter type vendor.
			   ,{ADAPTER_NAME + ADKGLOBAL.RESOURCEBUNDLEKEY_VENDORNAME, "Software AG"}
			   //Copyright URL Page
			   ,{ADAPTER_NAME + ADKGLOBAL.RESOURCEBUNDLEKEY_THIRDPARTYCOPYRIGHTURL, 
			    IS_PKG_NAME + "copyright.html"}
			   //Copyright Encoding
			   ,{ADAPTER_NAME + ADKGLOBAL.RESOURCEBUNDLEKEY_COPYRIGHTENCODING, "UTF-8"}
					 //About URL Page
			   ,{ADAPTER_NAME + ADKGLOBAL.RESOURCEBUNDLEKEY_ABOUT, IS_PKG_NAME + "About.html"}
			   //Release Notes URL Page
			   ,{ADAPTER_NAME + ADKGLOBAL.RESOURCEBUNDLEKEY_RELEASENOTEURL, IS_PKG_NAME + "ReleaseNotes.html"}
			  };
	@Override
	protected Object[][] getContents() {
		// TODO Auto-generated method stub
		return _contents;
	}

}
