package com.wm.adapter.WmModBosAdapter;

public interface WmModBusAdapterConstants {
	static final int ADAPTER_MAJOR_CODE = 9001;
    static final String ADAPTER_JCA_VERSION = "1.0";
	static final String ADAPTER_NAME = "WmModBusAdapter";
	static final String ADAPTER_VERSION = "9.12";
			
	//Using next statement creates cyclic class loading dependency issue
	//therefore, the resource bundle class name is fully spelled out
	//static final String ADAPTER_SOURCE_BUNDLE_NAME = MyAdapterResource.class.getName();
 static final String ADAPTER_SOURCE_BUNDLE_NAME =
		"com.wm.adapter.WmModBusAdapter.WmModBusAdapterResource";
}
